# ppppp > 2023-09-24 1:49am
https://universe.roboflow.com/p-kgnk7/ppppp-ocsge

Provided by a Roboflow user
License: CC BY 4.0

